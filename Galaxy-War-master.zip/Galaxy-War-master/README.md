# Galaxy-War
A Call of War clone type game.

# Updates
This game is currently in the making. The current script is only a test script for loading files into memory.
